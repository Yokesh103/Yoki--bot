NSE_API='https://www.nseindia.com/api'
BACKTEST_CSV = '/mnt/data/Backtest Stocks Trading above Previous 20 Day High, Technical Analysis Scanner.csv'
